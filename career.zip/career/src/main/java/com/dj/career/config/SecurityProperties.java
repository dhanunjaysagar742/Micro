package com.dj.career.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "security")
@Data
public class SecurityProperties {
    
    private Jwt jwt = new Jwt();
    private RateLimit rateLimit = new RateLimit();
    private Session session = new Session();
    
    @Data
    public static class Jwt {
        private String secret = "MySecureIntranetSecretKey2024!@#$%^&*()";
        private long expiration = 3600000; // 1 hour
        private String cookieName = "INTRANET_TOKEN";
        private boolean httpOnly = true;
        private boolean secure = true;
        private String sameSite = "Strict";
    }
    
    @Data
    public static class RateLimit {
        private int requestsPerMinute = 100;
        private boolean enabled = true;
    }
    
    @Data
    public static class Session {
        private long timeoutMinutes = 30;
        private long warningMinutes = 5;
        private boolean trackActivity = true;
    }
}

