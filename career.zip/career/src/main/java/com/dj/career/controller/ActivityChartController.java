package com.dj.career.controller;



import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.Principal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Random;

@RestController
@RequestMapping("/api/dashboard")
@PreAuthorize("isAuthenticated()")
@RequiredArgsConstructor
@Slf4j
public class ActivityChartController {

    @GetMapping("/activity-chart")
    public ResponseEntity<List<Map<String, Object>>> getActivityChartData(Principal principal) {
        // Mock data for activity chart
        Random random = new Random();
        List<Map<String, Object>> chartData = List.of(
            Map.of("timestamp", LocalDateTime.now().minusHours(6), "count", random.nextInt(10) + 1, "action", "LOGIN"),
            Map.of("timestamp", LocalDateTime.now().minusHours(5), "count", random.nextInt(15) + 5, "action", "PAGE_VIEW"),
            Map.of("timestamp", LocalDateTime.now().minusHours(4), "count", random.nextInt(8) + 2, "action", "DOWNLOAD"),
            Map.of("timestamp", LocalDateTime.now().minusHours(3), "count", random.nextInt(12) + 3, "action", "SEARCH"),
            Map.of("timestamp", LocalDateTime.now().minusHours(2), "count", random.nextInt(20) + 8, "action", "PAGE_VIEW"),
            Map.of("timestamp", LocalDateTime.now().minusHours(1), "count", random.nextInt(6) + 1, "action", "LOGOUT")
        );
        
        return ResponseEntity.ok(chartData);
    }
}

