package com.dj.career.controller;

import com.dj.career.dto.*;
import com.dj.career.service.UserService;
import com.dj.career.service.AttendanceService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
@Tag(name = "Admin Management", description = "APIs for admin operations")
@PreAuthorize("hasRole('ADMIN')")
@CrossOrigin(origins = "*", maxAge = 3600)
public class AdminController {
    
    private final UserService userService;
    private final AttendanceService attendanceService;
    
    @PostMapping("/users")
    @Operation(summary = "Create new user", description = "Admin creates a new user")
    public ResponseEntity<ApiResponse> createUser(@Valid @RequestBody CreateUserRequest request) {
        UserResponse user = userService.createUser(request);
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success("User created successfully", user));
    }
    
    @GetMapping("/users")
    @Operation(summary = "Get all users", description = "Admin gets paginated list of all users")
    public ResponseEntity<ApiResponse> getAllUsers(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDir) {
        
        Page<UserResponse> users = userService.getAllUsers(page, size, sortBy, sortDir);
        
        PageResponse<UserResponse> pageResponse = new PageResponse<>();
        pageResponse.setContent(users.getContent());
        pageResponse.setPageNumber(users.getNumber());
        pageResponse.setPageSize(users.getSize());
        pageResponse.setTotalElements(users.getTotalElements());
        pageResponse.setTotalPages(users.getTotalPages());
        pageResponse.setFirst(users.isFirst());
        pageResponse.setLast(users.isLast());
        pageResponse.setEmpty(users.isEmpty());
        
        return ResponseEntity.ok(ApiResponse.success("Users retrieved successfully", pageResponse));
    }
    
    @GetMapping("/users/search")
    @Operation(summary = "Search users", description = "Admin searches users")
    public ResponseEntity<ApiResponse> searchUsers(
            @RequestParam String search,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDir) {
        
        Page<UserResponse> users = userService.searchUsers(search, page, size, sortBy, sortDir);
        
        PageResponse<UserResponse> pageResponse = new PageResponse<>();
        pageResponse.setContent(users.getContent());
        pageResponse.setPageNumber(users.getNumber());
        pageResponse.setPageSize(users.getSize());
        pageResponse.setTotalElements(users.getTotalElements());
        pageResponse.setTotalPages(users.getTotalPages());
        pageResponse.setFirst(users.isFirst());
        pageResponse.setLast(users.isLast());
        pageResponse.setEmpty(users.isEmpty());
        
        return ResponseEntity.ok(ApiResponse.success("Users search completed", pageResponse));
    }
    
    @GetMapping("/users/{id}")
    @Operation(summary = "Get user by ID", description = "Admin gets user by ID")
    public ResponseEntity<ApiResponse> getUserById(@PathVariable Long id) {
        UserResponse user = userService.getUserById(id);
        return ResponseEntity.ok(ApiResponse.success("User retrieved successfully", user));
    }
    
    @PutMapping("/users/{id}")
    @Operation(summary = "Update user", description = "Admin updates user")
    public ResponseEntity<ApiResponse> updateUser(@PathVariable Long id, 
                                                @Valid @RequestBody UpdateUserRequest request) {
        UserResponse user = userService.updateUser(id, request);
        return ResponseEntity.ok(ApiResponse.success("User updated successfully", user));
    }
    
    @DeleteMapping("/users/{id}")
    @Operation(summary = "Delete user", description = "Admin deletes user")
    public ResponseEntity<ApiResponse> deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
        return ResponseEntity.ok(ApiResponse.success("User deleted successfully"));
    }
    
    @PutMapping("/users/{id}/enable")
    @Operation(summary = "Enable user", description = "Admin enables user")
    public ResponseEntity<ApiResponse> enableUser(@PathVariable Long id) {
        userService.enableUser(id);
        return ResponseEntity.ok(ApiResponse.success("User enabled successfully"));
    }
    
    @PutMapping("/users/{id}/disable")
    @Operation(summary = "Disable user", description = "Admin disables user")
    public ResponseEntity<ApiResponse> disableUser(@PathVariable Long id) {
        userService.disableUser(id);
        return ResponseEntity.ok(ApiResponse.success("User disabled successfully"));
    }
    
    @GetMapping("/attendance/reports")
    @Operation(summary = "Get attendance reports", description = "Admin gets comprehensive attendance reports")
    public ResponseEntity<ApiResponse> getAttendanceReports(
            @RequestParam(defaultValue = "1") int month,
            @RequestParam(defaultValue = "2025") int year) {
        
        MonthlyAttendanceReportRequest request = new MonthlyAttendanceReportRequest();
        request.setMonth(month);
        request.setYear(year);
        
        MonthlyAttendanceReportResponse report = attendanceService.generateMonthlyReport(request);
        return ResponseEntity.ok(ApiResponse.success("Attendance report generated", report));
    }
    
    @GetMapping("/dashboard/stats")
    @Operation(summary = "Get admin dashboard stats", description = "Admin gets dashboard statistics")
    public ResponseEntity<ApiResponse> getDashboardStats() {
        AttendanceStatistics stats = attendanceService.getDashboardStatistics();
        return ResponseEntity.ok(ApiResponse.success("Dashboard statistics retrieved", stats));
    }
}
