package com.dj.career.controller;

import com.dj.career.dto.ApiResponse;
import com.dj.career.dto.AttendanceStatusResponse;
import com.dj.career.dto.CheckInRequest;
import com.dj.career.dto.CheckOutRequest;
import com.dj.career.security.UserPrincipal;
import com.dj.career.service.AttendanceService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.validation.Valid; // Changed from javax to jakarta
import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/attendance")
@PreAuthorize("hasRole('USER') or hasRole('ADMIN')")
@CrossOrigin(origins = "*", maxAge = 3600)
public class AttendanceController {
    
    @Autowired
    private AttendanceService attendanceService;
    
    @PostMapping("/checkin")
    public ResponseEntity<ApiResponse> checkIn(@Valid @RequestBody CheckInRequest request,
                                             @AuthenticationPrincipal UserPrincipal currentUser) {
        try {
            AttendanceStatusResponse response = attendanceService.checkIn(currentUser.getId(), request);
            return ResponseEntity.ok(ApiResponse.success("Check-in successful", response));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error(e.getMessage()));
        }
    }
    
    @PostMapping("/checkout")
    public ResponseEntity<ApiResponse> checkOut(@Valid @RequestBody CheckOutRequest request,
                                              @AuthenticationPrincipal UserPrincipal currentUser) {
        try {
            AttendanceStatusResponse response = attendanceService.checkOut(currentUser.getId(), request);
            return ResponseEntity.ok(ApiResponse.success("Check-out successful", response));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error(e.getMessage()));
        }
    }
    
    @GetMapping("/history")
    public ResponseEntity<ApiResponse> getAttendanceHistory(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        
        List<AttendanceStatusResponse> records = attendanceService.getUserAttendance(
            currentUser.getId(), startDate, endDate);
        return ResponseEntity.ok(ApiResponse.success("Attendance history retrieved", records));
    }
    
    @GetMapping("/history/paginated")
    public ResponseEntity<ApiResponse> getAttendanceHistoryPaginated(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        Page<AttendanceStatusResponse> records = attendanceService.getAttendanceHistory(
            currentUser.getId(), page, size);
        return ResponseEntity.ok(ApiResponse.success("Attendance history retrieved", records));
    }
    
    @GetMapping("/status")
    public ResponseEntity<ApiResponse> getCurrentAttendanceStatus(@AuthenticationPrincipal UserPrincipal currentUser) {
        AttendanceStatusResponse status = attendanceService.getCurrentStatus(currentUser.getId());
        return ResponseEntity.ok(ApiResponse.success("Current status retrieved", status));
    }
    
    @GetMapping("/summary")
    public ResponseEntity<ApiResponse> getAttendanceSummary(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @RequestParam(defaultValue = "1") int month,
            @RequestParam(defaultValue = "2025") int year) {
        
        Object summary = attendanceService.getMonthlySummary(currentUser.getId(), month, year);
        return ResponseEntity.ok(ApiResponse.success("Monthly summary retrieved", summary));
    }
}
