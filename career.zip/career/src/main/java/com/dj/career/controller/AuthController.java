package com.dj.career.controller;

import com.dj.career.dto.ApiResponse;
import com.dj.career.dto.CreateUserRequest;
import com.dj.career.dto.JwtAuthResponse;
import com.dj.career.dto.LoginRequest;
import com.dj.career.dto.UserResponse;
import com.dj.career.security.JwtTokenProvider;
import com.dj.career.security.UserPrincipal;
import com.dj.career.service.UserService;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@Slf4j
@CrossOrigin(origins = "*", maxAge = 3600)
public class AuthController {
    
    private final AuthenticationManager authenticationManager;
    private final JwtTokenProvider tokenProvider;
    private final UserService userService;
    
    @Value("${jwt.cookie.name}")
    private String cookieName;
    
    @PostMapping("/login")
    public ResponseEntity<ApiResponse> authenticateUser(@Valid @RequestBody LoginRequest loginRequest,
                                                       HttpServletResponse response) {
        try {
            log.info("Login attempt for username: {}", loginRequest.getUsername());
            
            Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                    loginRequest.getUsername(),
                    loginRequest.getPassword()
                )
            );
            
            SecurityContextHolder.getContext().setAuthentication(authentication);
            
            UserPrincipal userPrincipal = (UserPrincipal) authentication.getPrincipal();
            String jwt = tokenProvider.generateToken(authentication);
            
            // Set JWT in cookie
            Cookie jwtCookie = new Cookie(cookieName, jwt);
            jwtCookie.setHttpOnly(true);
            jwtCookie.setSecure(false); // Set to true in production with HTTPS
            jwtCookie.setPath("/");
            jwtCookie.setMaxAge((int) (tokenProvider.getJwtExpirationInMs() / 1000));
            response.addCookie(jwtCookie);
            
            // Get user details for response
            UserResponse userResponse = userService.getUserById(userPrincipal.getId());
            
            JwtAuthResponse jwtResponse = JwtAuthResponse.create(
            	    jwt,
            	    tokenProvider.getJwtExpirationInMs(),
            	    userResponse.getUsername(),
            	    userResponse.getFullName(),
            	    userResponse.getEmail(),
            	    userResponse.getRoles()
            	);

            
            log.info("User {} logged in successfully", loginRequest.getUsername());
            return ResponseEntity.ok(ApiResponse.success("Login successful", jwtResponse));
            
        } catch (BadCredentialsException e) {
            log.warn("Failed login attempt for username: {}", loginRequest.getUsername());
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(ApiResponse.error("Invalid username or password"));
        } catch (Exception e) {
            log.error("Login error for username: {}", loginRequest.getUsername(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("An error occurred during login"));
        }
    }
    
    @PostMapping("/register")
    public ResponseEntity<ApiResponse> registerUser(@Valid @RequestBody CreateUserRequest signUpRequest) {
        try {
            log.info("Registration attempt for username: {}", signUpRequest.getUsername());
            
            if (userService.existsByUsername(signUpRequest.getUsername())) {
                log.warn("Registration failed - username already exists: {}", signUpRequest.getUsername());
                return ResponseEntity.status(HttpStatus.CONFLICT)
                        .body(ApiResponse.error("Username is already taken"));
            }
            
            if (signUpRequest.getEmail() != null && userService.existsByEmail(signUpRequest.getEmail())) {
                log.warn("Registration failed - email already exists: {}", signUpRequest.getEmail());
                return ResponseEntity.status(HttpStatus.CONFLICT)
                        .body(ApiResponse.error("Email address is already in use"));
            }
            
            UserResponse newUser = userService.createUser(signUpRequest);
            
            log.info("User registered successfully: {}", signUpRequest.getUsername());
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(ApiResponse.success("User registered successfully", newUser));
            
        } catch (Exception e) {
            log.error("Registration error for username: {}", signUpRequest.getUsername(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("An error occurred during registration"));
        }
    }
    
    @PostMapping("/logout")
    public ResponseEntity<ApiResponse> logoutUser(@AuthenticationPrincipal UserPrincipal currentUser,
                                                 HttpServletResponse response) {
        try {
            if (currentUser != null) {
                log.info("User {} logging out", currentUser.getUsername());
            }
            
            // Clear the JWT cookie
            Cookie jwtCookie = new Cookie(cookieName, null);
            jwtCookie.setHttpOnly(true);
            jwtCookie.setSecure(false);
            jwtCookie.setPath("/");
            jwtCookie.setMaxAge(0);
            response.addCookie(jwtCookie);
            
            SecurityContextHolder.clearContext();
            
            return ResponseEntity.ok(ApiResponse.success("Logged out successfully"));
            
        } catch (Exception e) {
            log.error("Logout error", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ApiResponse.error("An error occurred during logout"));
        }
    }
}
