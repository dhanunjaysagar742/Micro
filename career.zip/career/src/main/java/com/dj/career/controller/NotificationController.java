package com.dj.career.controller;

import com.dj.career.dto.ApiResponse;
import com.dj.career.dto.NotificationResponse;
import com.dj.career.dto.PageResponse;
import com.dj.career.security.UserPrincipal;
import com.dj.career.service.NotificationService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/notifications")
@PreAuthorize("hasRole('USER') or hasRole('ADMIN')")
@CrossOrigin(origins = "*", maxAge = 3600)
public class NotificationController {
    
    @Autowired
    private NotificationService notificationService;
    
    @GetMapping
    public ResponseEntity<ApiResponse> getUserNotifications(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @RequestParam(defaultValue = "false") boolean unreadOnly,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        if (unreadOnly) {
            // Get unread notifications only
            List<NotificationResponse> notifications = notificationService.getUnreadNotifications(currentUser.getId());
            return ResponseEntity.ok(ApiResponse.success("Unread notifications retrieved", notifications));
        } else {
            // Get paginated notifications
            Page<NotificationResponse> notifications = notificationService.getUserNotifications(
                currentUser.getId(), page, size);
            
            PageResponse<NotificationResponse> pageResponse = new PageResponse<>();
            pageResponse.setContent(notifications.getContent());
            pageResponse.setPageNumber(notifications.getNumber());
            pageResponse.setPageSize(notifications.getSize());
            pageResponse.setTotalElements(notifications.getTotalElements());
            pageResponse.setTotalPages(notifications.getTotalPages());
            pageResponse.setFirst(notifications.isFirst());
            pageResponse.setLast(notifications.isLast());
            pageResponse.setEmpty(notifications.isEmpty());
            
            return ResponseEntity.ok(ApiResponse.success("Notifications retrieved", pageResponse));
        }
    }
    
    @GetMapping("/unread")
    public ResponseEntity<ApiResponse> getUnreadNotifications(@AuthenticationPrincipal UserPrincipal currentUser) {
        List<NotificationResponse> notifications = notificationService.getUnreadNotifications(currentUser.getId());
        return ResponseEntity.ok(ApiResponse.success("Unread notifications retrieved", notifications));
    }
    
    @PutMapping("/{id}/read")
    public ResponseEntity<ApiResponse> markAsRead(@PathVariable Long id,
                                                @AuthenticationPrincipal UserPrincipal currentUser) {
        try {
            notificationService.markAsRead(id, currentUser.getId());
            return ResponseEntity.ok(ApiResponse.success("Notification marked as read"));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error(e.getMessage()));
        }
    }
    
    @PutMapping("/read-all")
    public ResponseEntity<ApiResponse> markAllAsRead(@AuthenticationPrincipal UserPrincipal currentUser) {
        notificationService.markAllAsRead(currentUser.getId());
        return ResponseEntity.ok(ApiResponse.success("All notifications marked as read"));
    }
    
    @GetMapping("/unread-count")
    public ResponseEntity<ApiResponse> getUnreadCount(@AuthenticationPrincipal UserPrincipal currentUser) {
        Long count = notificationService.getUnreadCount(currentUser.getId());
        return ResponseEntity.ok(ApiResponse.success("Unread count retrieved", count));
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse> deleteNotification(@PathVariable Long id,
                                                        @AuthenticationPrincipal UserPrincipal currentUser) {
        try {
            notificationService.deleteNotification(id, currentUser.getId());
            return ResponseEntity.ok(ApiResponse.success("Notification deleted successfully"));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                    .body(ApiResponse.error(e.getMessage()));
        }
    }
}
