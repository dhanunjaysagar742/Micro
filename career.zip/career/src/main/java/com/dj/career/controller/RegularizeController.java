package com.dj.career.controller;

import com.dj.career.dto.ApiResponse;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.time.LocalDateTime;
import java.util.Map;

@RestController
@RequestMapping("/api/regularize")
@PreAuthorize("isAuthenticated()")
@RequiredArgsConstructor
@Slf4j
public class RegularizeController {
    
    @GetMapping("/status")
    public ResponseEntity<ApiResponse> getRegularizeStatus(Principal principal) { // Remove <Map<String, Object>>
        // Mock regularization status
        Map<String, Object> status = Map.of(
            "pendingRegularizations", 2,
            "lastRegularized", LocalDateTime.now().minusDays(1).toString(),
            "requiresAction", true
        );
        
        return ResponseEntity.ok(ApiResponse.success("Status retrieved", status));
    }
    
    @PostMapping("/submit")
    public ResponseEntity<ApiResponse> submitRegularization( // Remove <String>
            @RequestBody Map<String, Object> request,
            Principal principal,
            HttpServletRequest httpRequest) {
        
        log.info("Regularization submitted by: {}", principal.getName());
        
        // Process regularization logic here
        
        return ResponseEntity.ok(ApiResponse.success("Regularization submitted successfully"));
    }
    
    @GetMapping("/pending")
    public ResponseEntity<ApiResponse> getPendingRegularizations(Principal principal) {
        // Mock pending regularizations
        var pendingList = Map.of(
            "regularizations", java.util.List.of(
                Map.of(
                    "id", 1,
                    "date", "2025-08-23",
                    "status", "PENDING",
                    "reason", "Forgot to check out"
                ),
                Map.of(
                    "id", 2,
                    "date", "2025-08-22",
                    "status", "PENDING", 
                    "reason", "Late arrival due to traffic"
                )
            ),
            "totalCount", 2
        );
        
        return ResponseEntity.ok(ApiResponse.success("Pending regularizations retrieved", pendingList));
    }
    
    @PutMapping("/{id}/approve")
    @PreAuthorize("hasRole('ADMIN') or hasRole('MANAGER')")
    public ResponseEntity<ApiResponse> approveRegularization(@PathVariable Long id, Principal principal) {
        log.info("Approving regularization {} by: {}", id, principal.getName());
        
        // Process approval logic here
        
        return ResponseEntity.ok(ApiResponse.success("Regularization approved successfully"));
    }
    
    @PutMapping("/{id}/reject")
    @PreAuthorize("hasRole('ADMIN') or hasRole('MANAGER')")
    public ResponseEntity<ApiResponse> rejectRegularization(
            @PathVariable Long id,
            @RequestBody Map<String, String> rejectionData,
            Principal principal) {
        
        String reason = rejectionData.get("reason");
        log.info("Rejecting regularization {} by: {} with reason: {}", id, principal.getName(), reason);
        
        // Process rejection logic here
        
        return ResponseEntity.ok(ApiResponse.success("Regularization rejected successfully"));
    }
}
