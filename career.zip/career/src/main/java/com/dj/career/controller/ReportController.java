package com.dj.career.controller;



//import com.dj.career.dto.MonthlyAttendanceReport;
import com.dj.career.service.ReportService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/reports")
@PreAuthorize("hasRole('ADMIN')")
@CrossOrigin(origins = "*", maxAge = 3600)
public class ReportController {
    
    @Autowired
    private ReportService reportService;
    
	/*
	 * @GetMapping("/attendance/monthly") public
	 * ResponseEntity<MonthlyAttendanceReport> getMonthlyAttendanceReport(
	 * 
	 * @RequestParam(defaultValue = "2025") int year,
	 * 
	 * @RequestParam(defaultValue = "1") int month) {
	 * 
	 * MonthlyAttendanceReport report = reportService.generateMonthlyReport(year,
	 * month); return ResponseEntity.ok(report); }
	 */
    
    @GetMapping("/attendance/export/excel")
    public ResponseEntity<byte[]> exportAttendanceReportExcel(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
            @RequestParam(required = false) Long userId) {
        
        byte[] reportData = reportService.exportToExcel(startDate, endDate, userId);
        
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=attendance_report.xlsx")
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .body(reportData);
    }
    
    @GetMapping("/attendance/export/pdf")
    public ResponseEntity<byte[]> exportAttendanceReportPdf(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
            @RequestParam(required = false) Long userId) {
        
        byte[] reportData = reportService.exportToPdf(startDate, endDate, userId);
        
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=attendance_report.pdf")
                .contentType(MediaType.APPLICATION_PDF)
                .body(reportData);
    }
    
    @GetMapping("/dashboard/stats")
    public ResponseEntity<?> getDashboardStats() {
        return ResponseEntity.ok(reportService.getDashboardStatistics());
    }
}

