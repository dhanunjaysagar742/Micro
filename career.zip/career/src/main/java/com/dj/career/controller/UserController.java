package com.dj.career.controller;

import com.dj.career.dto.ApiResponse;
import com.dj.career.dto.AttendanceStatusResponse;
import com.dj.career.dto.ChangePasswordRequest;
import com.dj.career.dto.UpdateUserRequest;
import com.dj.career.dto.UserResponse;
import com.dj.career.security.UserPrincipal;
import com.dj.career.service.UserService;
import com.dj.career.service.AttendanceService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.validation.Valid;
import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/users")
@PreAuthorize("hasRole('USER') or hasRole('ADMIN')")
@CrossOrigin(origins = "*", maxAge = 3600)
public class UserController {
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private AttendanceService attendanceService;
    
    @GetMapping("/profile")
    public ResponseEntity<ApiResponse> getCurrentUser(@AuthenticationPrincipal UserPrincipal currentUser) {
        UserResponse user = userService.getUserById(currentUser.getId());
        return ResponseEntity.ok(ApiResponse.success("User profile retrieved successfully", user));
    }
    
    @PutMapping("/profile")
    public ResponseEntity<ApiResponse> updateProfile(@Valid @RequestBody UpdateUserRequest request,
                                                   @AuthenticationPrincipal UserPrincipal currentUser) {
        UserResponse updatedUser = userService.updateUser(currentUser.getId(), request);
        return ResponseEntity.ok(ApiResponse.success("Profile updated successfully", updatedUser));
    }
    
    @GetMapping("/attendance")
    public ResponseEntity<ApiResponse> getUserAttendance(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
        
        // Fixed: Changed return type to match service
        List<AttendanceStatusResponse> attendanceRecords = attendanceService.getUserAttendance(
            currentUser.getId(), startDate, endDate);
        return ResponseEntity.ok(ApiResponse.success("Attendance records retrieved successfully", attendanceRecords));
    }
    
    @GetMapping("/dashboard")
    public ResponseEntity<ApiResponse> getUserDashboard(@AuthenticationPrincipal UserPrincipal currentUser) {
        Object dashboardData = userService.getUserDashboard(currentUser.getId());
        return ResponseEntity.ok(ApiResponse.success("Dashboard data retrieved successfully", dashboardData));
    }
    
    @GetMapping("/attendance/summary")
    public ResponseEntity<ApiResponse> getAttendanceSummary(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @RequestParam(defaultValue = "1") int month,
            @RequestParam(defaultValue = "2025") int year) {
        
        Object summary = attendanceService.getMonthlySummary(currentUser.getId(), month, year);
        return ResponseEntity.ok(ApiResponse.success("Attendance summary retrieved successfully", summary));
    }
    
    @GetMapping("/notifications")
    public ResponseEntity<ApiResponse> getUserNotifications(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @RequestParam(defaultValue = "false") boolean unreadOnly) {
        
        Object notifications = userService.getUserNotifications(currentUser.getId(), unreadOnly);
        return ResponseEntity.ok(ApiResponse.success("Notifications retrieved successfully", notifications));
    }
    
    @PutMapping("/change-password")
    public ResponseEntity<ApiResponse> changePassword(
            @Valid @RequestBody ChangePasswordRequest request, // Added @Valid
            @AuthenticationPrincipal UserPrincipal currentUser) {
        
        userService.changePassword(currentUser.getId(), request);
        return ResponseEntity.ok(ApiResponse.success("Password changed successfully"));
    }
}
