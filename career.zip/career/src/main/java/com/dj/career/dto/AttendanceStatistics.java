package com.dj.career.dto;

import lombok.Data;

@Data
public class AttendanceStatistics {
    private Double averageAttendanceRate;
    private Double punctualityRate;
    private Long totalWorkingHours;
    private Long totalOvertimeHours;
    private Integer totalPresentDays;
    private Integer totalAbsentDays;
    private Integer totalLateDays;
    private Integer totalEmployees;
}
