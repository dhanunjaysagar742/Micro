package com.dj.career.dto;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.validation.constraints.Pattern;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class AttendanceStatusResponse {
    private Long userId;
    private String username;
    private String fullName;
    private boolean checkedIn;
    
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime lastCheckInTime;
    
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime lastCheckOutTime;
    
    @Pattern(regexp = "^(CHECKED_IN|CHECKED_OUT|NOT_STARTED)$", message = "Invalid status")
    private String currentStatus;
    
    private Long totalWorkingMinutes;
    private String workMode;
    private String currentLocation;
}
