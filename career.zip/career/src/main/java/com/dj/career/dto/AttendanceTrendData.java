package com.dj.career.dto;

import lombok.Data;
import java.time.LocalDate;

@Data
public class AttendanceTrendData {
    private LocalDate date;
    private Integer totalAttendance;
    private Integer presentCount;
    private Integer absentCount;
    private Double attendanceRate;
}
