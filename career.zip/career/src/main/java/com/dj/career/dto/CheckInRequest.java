package com.dj.career.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class CheckInRequest {
    
    @NotNull(message = "Check-in time is required")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime checkInTime;
    
    @DecimalMin(value = "-90.0", message = "Latitude must be between -90 and 90")
    @DecimalMax(value = "90.0", message = "Latitude must be between -90 and 90")
    private Double latitude;
    
    @DecimalMin(value = "-180.0", message = "Longitude must be between -180 and 180")
    @DecimalMax(value = "180.0", message = "Longitude must be between -180 and 180")
    private Double longitude;
    
    @Size(max = 200, message = "Location name must not exceed 200 characters")
    private String locationName;
    
    @Size(max = 500, message = "Notes must not exceed 500 characters")
    private String notes;
    
    @Pattern(regexp = "^(OFFICE|REMOTE|HYBRID)$", message = "Work mode must be OFFICE, REMOTE, or HYBRID")
    private String workMode = "OFFICE";
}
