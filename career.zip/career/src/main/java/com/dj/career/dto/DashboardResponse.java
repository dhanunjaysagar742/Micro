package com.dj.career.dto;

import lombok.Data;
import java.time.LocalDate;

@Data
public class DashboardResponse {
    
    private AttendanceStatusResponse currentUserStatus;
    private UserAttendanceSummary monthlySummary;
    private LocalDate todayDate;
    private Integer totalWorkingDaysThisMonth;
    private Integer remainingWorkingDays;
}
