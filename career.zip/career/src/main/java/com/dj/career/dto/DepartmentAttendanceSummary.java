package com.dj.career.dto;

import lombok.Data;

@Data
public class DepartmentAttendanceSummary {
    private String departmentName;
    private Integer totalEmployees;
    private Integer totalPresentDays;
    private Double averageAttendanceRate;
}
