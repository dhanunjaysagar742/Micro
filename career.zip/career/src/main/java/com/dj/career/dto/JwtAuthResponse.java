package com.dj.career.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.Set;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class JwtAuthResponse {
    
    private String accessToken;
    
    @Builder.Default
    private String tokenType = "Bearer";
    
    private Long expiresIn;
    private String username;
    private String fullName;
    private String email;
    private Set<String> roles;
    
    // Static factory method (alternative to builder)
    public static JwtAuthResponse create(String accessToken, Long expiresIn, 
                                       String username, String fullName, 
                                       String email, Set<String> roles) {
        return JwtAuthResponse.builder()
                .accessToken(accessToken)
                .expiresIn(expiresIn)
                .username(username)
                .fullName(fullName)
                .email(email)
                .roles(roles)
                .build();
    }
}
