package com.dj.career.dto;

import lombok.Data;
import java.util.List;

@Data
public class MonthlyAttendanceReportResponse {
    private Integer year;
    private Integer month;
    private String monthName;
    private Integer totalWorkingDays;
    private Integer totalEmployees;
    private List<UserAttendanceSummary> userSummaries;
    private AttendanceStatistics overallStats;
}
