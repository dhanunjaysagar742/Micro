package com.dj.career.dto;

import com.dj.career.entity.NotificationType;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class NotificationResponse {
    private Long id;
    private Long userId;
    private String userFullName;
    private String title;
    private String message;
    private NotificationType type;
    private Boolean read;
    private String actionUrl;
    private String relatedEntityType;
    private Long relatedEntityId;
    
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createdAt;
    
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime updatedAt;
}
