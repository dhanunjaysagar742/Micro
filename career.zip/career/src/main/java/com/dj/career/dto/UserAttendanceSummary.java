package com.dj.career.dto;

import lombok.Data;

@Data
public class UserAttendanceSummary {
    private Long userId;
    private String username;
    private String fullName;
    private String department;
    private String designation;
    private Integer presentDays;
    private Integer absentDays;
    private Integer lateDays;
    private Long totalWorkingHours;
    private Long totalOvertimeHours;
    private Double attendancePercentage;
    private Double punctualityRate;
}
