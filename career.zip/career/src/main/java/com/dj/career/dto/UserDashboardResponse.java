package com.dj.career.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
public class UserDashboardResponse {
    private Long userId;
    private String fullName;
    private String email;
    private String department;
    private String designation;
    
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate todayDate;
    
    private Long unreadNotificationCount;
    private List<NotificationResponse> recentNotifications;
    
    // Additional dashboard metrics can be added here
    private Integer thisMonthPresentDays;
    private Integer thisMonthAbsentDays;
    private Double thisMonthAttendancePercentage;
}
