package com.dj.career.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "attendance_records", indexes = {
    @Index(name = "idx_user_date", columnList = "user_id, check_in_time"),
    @Index(name = "idx_check_in_time", columnList = "check_in_time"),
    @Index(name = "idx_attendance_status", columnList = "attendance_status")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AttendanceRecord {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;
    
    @Column(name = "check_in_time", nullable = false)
    private LocalDateTime checkInTime;
    
    @Column(name = "check_out_time")
    private LocalDateTime checkOutTime;
    
    // Location tracking
    @Column(name = "check_in_latitude")
    private Double checkInLatitude;
    
    @Column(name = "check_in_longitude")
    private Double checkInLongitude;
    
    @Column(name = "check_out_latitude")
    private Double checkOutLatitude;
    
    @Column(name = "check_out_longitude")
    private Double checkOutLongitude;
    
    @Column(name = "check_in_location", length = 200)
    private String checkInLocation;
    
    @Column(name = "check_out_location", length = 200)
    private String checkOutLocation;
    
    // Work mode and notes
    @Enumerated(EnumType.STRING)
    @Column(name = "work_mode", nullable = false)
    private WorkMode workMode = WorkMode.OFFICE;
    
    @Column(name = "check_in_notes", length = 500)
    private String checkInNotes;
    
    @Column(name = "check_out_notes", length = 500)
    private String checkOutNotes;
    
    @Column(name = "work_summary", length = 1000)
    private String workSummary;
    
    // Time calculations
    @Column(name = "total_working_minutes")
    private Long totalWorkingMinutes;
    
    // Attendance status and flags
    @Column(name = "attendance_status", length = 20)
    private String attendanceStatus; // PRESENT, ABSENT, HALF_DAY
    
    @Column(name = "is_late")
    private Boolean isLate = false;
    
    // Regularization fields
    @Column(name = "is_regularized")
    private Boolean regularized = false;
    
    @Column(name = "regularization_reason", length = 500)
    private String regularizationReason;
    
    @Column(name = "regularization_status", length = 20)
    private String regularizationStatus; // PENDING, APPROVED, REJECTED
    
    @Column(name = "approved_by")
    private Long approvedBy;
    
    @Column(name = "approval_date")
    private LocalDateTime approvalDate;
    
    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;
    
    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    
    // Helper methods
    public boolean isCheckedIn() {
        return checkInTime != null && checkOutTime == null;
    }
    
    public boolean isCompleted() {
        return checkInTime != null && checkOutTime != null;
    }
    
    // Getters for convenience
    public boolean isLate() {
        return Boolean.TRUE.equals(isLate);
    }
    
    public boolean isRegularized() {
        return Boolean.TRUE.equals(regularized);
    }
}
