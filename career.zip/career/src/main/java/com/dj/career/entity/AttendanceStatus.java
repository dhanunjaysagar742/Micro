package com.dj.career.entity;

public enum AttendanceStatus {
    PRESENT,
    ABSENT,
    HALF_DAY,
    LATE,
    ON_LEAVE
}
