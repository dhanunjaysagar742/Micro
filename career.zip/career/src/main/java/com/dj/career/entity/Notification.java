package com.dj.career.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "notifications", indexes = {
    @Index(name = "idx_user_id", columnList = "user_id"),
    @Index(name = "idx_is_read", columnList = "is_read"),
    @Index(name = "idx_created_at", columnList = "created_at")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Notification {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;
    
    @Column(nullable = false, length = 500)
    private String message;
    
    @Column(nullable = false, length = 100)
    private String title;
    
    @Enumerated(EnumType.STRING)
    @Column(name = "notification_type", nullable = false)
    private NotificationType type = NotificationType.INFO;
    
    @Column(name = "is_read", nullable = false)
    private Boolean read = false;
    
    @Column(name = "action_url")
    private String actionUrl;
    
    // For attendance-related notifications
    @Column(name = "related_entity_type")
    private String relatedEntityType; // ATTENDANCE, USER, REPORT
    
    @Column(name = "related_entity_id")
    private Long relatedEntityId;
    
    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;
    
    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    
    // Constructors for convenience
    public Notification(User user, String title, String message, NotificationType type) {
        this.user = user;
        this.title = title;
        this.message = message;
        this.type = type;
        this.read = false;
    }
    
    public Notification(User user, String title, String message, NotificationType type, String actionUrl) {
        this(user, title, message, type);
        this.actionUrl = actionUrl;
    }
    
    // Helper methods
    public boolean isRead() {
        return Boolean.TRUE.equals(read);
    }
}
