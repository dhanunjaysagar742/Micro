package com.dj.career.entity;

public enum NotificationType {
    INFO,
    SUCCESS,
    WARNING,
    ERROR,
    REMINDER,
    APPROVAL_REQUEST,
    APPROVAL_GRANTED,
    APPROVAL_DENIED
}
