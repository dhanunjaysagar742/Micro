package com.dj.career.entity;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "user_activities", indexes = {
    @Index(name = "idx_username", columnList = "username"),
    @Index(name = "idx_timestamp", columnList = "timestamp"),
    @Index(name = "idx_action", columnList = "action")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserActivity {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false, length = 50)
    private String username;
    
    @Column(name = "ip_address", length = 45)
    private String ipAddress;
    
    @Column(name = "user_agent", length = 500)
    private String userAgent;
    
    @Column(nullable = false, length = 50)
    private String action;
    
    @Column(name = "resource_accessed", length = 255)
    private String resourceAccessed;
    
    @Column(name = "session_id", length = 100)
    private String sessionId;
    
    @Column(name = "device_info", length = 255)
    private String deviceInfo;
    
    @Column(name = "browser_fingerprint", length = 255)
    private String browserFingerprint;
    
    @CreationTimestamp
    @Column(nullable = false, updatable = false)
    private LocalDateTime timestamp;
    
    @Column(name = "additional_info", columnDefinition = "TEXT")
    private String additionalInfo;
}
