package com.dj.career.entity;

public enum WorkMode {
    OFFICE,
    REMOTE, 
    HYBRID
}
