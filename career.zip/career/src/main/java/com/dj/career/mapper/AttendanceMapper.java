package com.dj.career.mapper;

import com.dj.career.dto.AttendanceStatusResponse;
import com.dj.career.dto.UserAttendanceSummary;
import com.dj.career.entity.AttendanceRecord;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.util.List;

@Mapper(componentModel = "spring")
public interface AttendanceMapper {
    
    @Mapping(source = "user.id", target = "userId")
    @Mapping(source = "user.username", target = "username")
    @Mapping(source = "user.fullName", target = "fullName")
    @Mapping(source = "workMode", target = "workMode", qualifiedByName = "workModeToString")
    @Mapping(target = "currentStatus", source = ".", qualifiedByName = "determineStatus")
    @Mapping(target = "checkedIn", source = ".", qualifiedByName = "isCheckedIn")
    AttendanceStatusResponse toStatusResponse(AttendanceRecord record);
    
    @Mapping(source = "user.id", target = "userId")
    @Mapping(source = "user.username", target = "username")
    @Mapping(source = "user.fullName", target = "fullName")
    UserAttendanceSummary toUserSummary(AttendanceRecord record);
    
    List<AttendanceStatusResponse> toStatusResponseList(List<AttendanceRecord> records);
    
    // Custom mapping methods
    @Named("workModeToString")
    default String workModeToString(com.dj.career.entity.WorkMode workMode) {
        return workMode != null ? workMode.name() : "OFFICE";
    }
    
    @Named("determineStatus")
    default String determineStatus(AttendanceRecord record) {
        if (record.getCheckInTime() != null && record.getCheckOutTime() == null) {
            return "CHECKED_IN";
        } else if (record.getCheckInTime() != null && record.getCheckOutTime() != null) {
            return "CHECKED_OUT";
        } else {
            return "NOT_STARTED";
        }
    }
    
    @Named("isCheckedIn")
    default boolean isCheckedIn(AttendanceRecord record) {
        return record.getCheckInTime() != null && record.getCheckOutTime() == null;
    }
}
