package com.dj.career.mapper;

import com.dj.career.dto.NotificationResponse;
import com.dj.career.entity.Notification;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface NotificationMapper {
    
    @Mapping(source = "user.id", target = "userId")
    @Mapping(source = "user.fullName", target = "userFullName")
    NotificationResponse toResponse(Notification notification);
}
