package com.dj.career.repository;

import com.dj.career.entity.AttendanceRecord;
import com.dj.career.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface AttendanceRepository extends JpaRepository<AttendanceRecord, Long> {
    
    // Find active check-in (no check-out yet)
    Optional<AttendanceRecord> findByUserAndCheckOutTimeIsNull(User user);
    
    // Find attendance by user and date range
    List<AttendanceRecord> findByUserAndCheckInTimeBetween(User user, 
                                                          LocalDateTime start, 
                                                          LocalDateTime end);
    
    // Paginated attendance history
    Page<AttendanceRecord> findByUserOrderByCheckInTimeDesc(User user, Pageable pageable);
    
    // Find attendance by user and specific date
    @Query("SELECT ar FROM AttendanceRecord ar WHERE ar.user.id = :userId AND " +
           "DATE(ar.checkInTime) = :date")
    Optional<AttendanceRecord> findByUserIdAndDate(@Param("userId") Long userId, 
                                                  @Param("date") LocalDate date);
    
    // Today's statistics
    @Query("SELECT COUNT(ar) FROM AttendanceRecord ar WHERE " +
           "DATE(ar.checkInTime) = CURRENT_DATE")
    Long countTodayTotalAttendance();
    
    @Query("SELECT COUNT(ar) FROM AttendanceRecord ar WHERE " +
           "DATE(ar.checkInTime) = CURRENT_DATE AND ar.checkOutTime IS NOT NULL")
    Long countTodayCompletedAttendance();
    
    // Date range reports
    @Query("SELECT ar FROM AttendanceRecord ar WHERE " +
           "ar.checkInTime >= :startDate AND ar.checkInTime <= :endDate " +
           "ORDER BY ar.checkInTime DESC")
    List<AttendanceRecord> findAttendanceInDateRange(@Param("startDate") LocalDateTime startDate,
                                                   @Param("endDate") LocalDateTime endDate);
    
    // Monthly attendance summary
    @Query("SELECT ar FROM AttendanceRecord ar WHERE ar.user.id = :userId AND " +
           "YEAR(ar.checkInTime) = :year AND MONTH(ar.checkInTime) = :month")
    List<AttendanceRecord> findMonthlyAttendanceByUser(@Param("userId") Long userId,
                                                      @Param("year") int year,
                                                      @Param("month") int month);
    
    // Late arrivals count
    @Query("SELECT COUNT(ar) FROM AttendanceRecord ar WHERE ar.user.id = :userId AND " +
           "ar.isLate = true AND YEAR(ar.checkInTime) = :year AND MONTH(ar.checkInTime) = :month")
    Long countLateArrivalsByUserAndMonth(@Param("userId") Long userId,
                                        @Param("year") int year,
                                        @Param("month") int month);
    
    // Regularization queries
    @Query("SELECT ar FROM AttendanceRecord ar WHERE ar.regularized = true AND " +
           "ar.regularizationStatus = 'PENDING'")
    List<AttendanceRecord> findPendingRegularizations();
    
    @Query("SELECT ar FROM AttendanceRecord ar WHERE ar.user.id = :userId AND " +
           "ar.regularized = true ORDER BY ar.checkInTime DESC")
    List<AttendanceRecord> findRegularizationsByUser(@Param("userId") Long userId);
}
