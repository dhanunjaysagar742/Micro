package com.dj.career.repository;



import com.dj.career.entity.UserActivity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface UserActivityRepository extends JpaRepository<UserActivity, Long> {
    
    Page<UserActivity> findByUsernameOrderByTimestampDesc(String username, Pageable pageable);
    
    Page<UserActivity> findAllByOrderByTimestampDesc(Pageable pageable);
    
    UserActivity findFirstByUsernameAndActionOrderByTimestampDesc(String username, String action);
    
    Long countByUsernameAndTimestampAfter(String username, LocalDateTime timestamp);
    
    @Query("SELECT COUNT(DISTINCT ua.sessionId) FROM UserActivity ua WHERE ua.username = :username")
    Long countDistinctSessionsByUsername(@Param("username") String username);
    
    @Query("""
        SELECT ua.username, MAX(ua.timestamp), ua.ipAddress 
        FROM UserActivity ua 
        WHERE ua.timestamp > :since 
        GROUP BY ua.username, ua.ipAddress 
        ORDER BY MAX(ua.timestamp) DESC
        """)
    List<Object[]> findActiveUsersSince(@Param("since") LocalDateTime since);
    
    List<UserActivity> findByUsernameAndTimestampBetween(
            String username, LocalDateTime start, LocalDateTime end);
    
    @Query("""
        SELECT ua.action, COUNT(ua) 
        FROM UserActivity ua 
        WHERE ua.username = :username AND ua.timestamp > :since 
        GROUP BY ua.action
        """)
    List<Object[]> findActivityCountsByUser(
            @Param("username") String username, 
            @Param("since") LocalDateTime since);
}

