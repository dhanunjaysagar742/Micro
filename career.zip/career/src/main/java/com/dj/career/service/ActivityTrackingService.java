package com.dj.career.service;



import com.dj.career.entity.UserActivity;
import com.dj.career.repository.UserActivityRepository;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class ActivityTrackingService {

    private final UserActivityRepository activityRepository;

    @Transactional
    public void trackActivity(String username, String ipAddress, String userAgent,
                            String action, String resourceAccessed, HttpServletRequest request) {
        try {
            UserActivity activity = new UserActivity();
            activity.setUsername(username);
            activity.setIpAddress(ipAddress);
            activity.setUserAgent(userAgent);
            activity.setAction(action);
            activity.setResourceAccessed(resourceAccessed);
            activity.setSessionId(request.getSession().getId());
            activity.setDeviceInfo(extractDeviceInfo(userAgent));
            activity.setBrowserFingerprint(generateBrowserFingerprint(request));
            
            // Additional info as JSON
            Map<String, Object> additionalInfo = new HashMap<>();
            additionalInfo.put("referer", request.getHeader("Referer"));
            additionalInfo.put("accept-language", request.getHeader("Accept-Language"));
            additionalInfo.put("timestamp", LocalDateTime.now().toString());
            
            activity.setAdditionalInfo(additionalInfo.toString());
            
            activityRepository.save(activity);
            log.debug("Activity tracked: {} - {} - {}", username, action, ipAddress);
            
        } catch (Exception e) {
            log.error("Failed to track activity for user: {}", username, e);
        }
    }

    @Transactional(readOnly = true)
    public Page<UserActivity> getUserActivities(String username, Pageable pageable) {
        return activityRepository.findByUsernameOrderByTimestampDesc(username, pageable);
    }

    @Transactional(readOnly = true)
    public Page<UserActivity> getAllActivities(Pageable pageable) {
        return activityRepository.findAllByOrderByTimestampDesc(pageable);
    }

    @Transactional(readOnly = true)
    public Map<String, Object> getUserStats(String username) {
        Map<String, Object> stats = new HashMap<>();
        
        // Count total sessions
        Long totalSessions = activityRepository.countDistinctSessionsByUsername(username);
        stats.put("totalSessions", totalSessions);
        
        // Count today's activities
        LocalDateTime startOfDay = LocalDateTime.now().withHour(0).withMinute(0).withSecond(0);
        Long todayActivities = activityRepository.countByUsernameAndTimestampAfter(username, startOfDay);
        stats.put("todayActivities", todayActivities);
        
        // Calculate active hours (mock calculation)
        stats.put("activeHours", todayActivities / 10); // Rough estimate
        
        // Last login
        UserActivity lastLogin = activityRepository.findFirstByUsernameAndActionOrderByTimestampDesc(
                username, "LOGIN");
        stats.put("lastLogin", lastLogin != null ? lastLogin.getTimestamp().toString() : "Never");
        
        return stats;
    }

    @Transactional(readOnly = true)
    public List<Map<String, Object>> getOnlineUsers() {
        LocalDateTime since = LocalDateTime.now().minusMinutes(30);
        List<Object[]> activeUsers = activityRepository.findActiveUsersSince(since);
        
        return activeUsers.stream()
                .map(row -> {
                    Map<String, Object> user = new HashMap<>();
                    user.put("username", row[0]);
                    user.put("lastActivity", row[24]);
                    user.put("ipAddress", row[1]);
                    return user;
                })
                .toList();
    }

    private String extractDeviceInfo(String userAgent) {
        if (userAgent == null) return "Unknown";
        
        if (userAgent.contains("Mobile")) return "Mobile";
        if (userAgent.contains("Tablet")) return "Tablet";
        return "Desktop";
    }

    private String generateBrowserFingerprint(HttpServletRequest request) {
        String userAgent = request.getHeader("User-Agent");
        String acceptLanguage = request.getHeader("Accept-Language");
        String acceptEncoding = request.getHeader("Accept-Encoding");
        
        return String.valueOf((userAgent + acceptLanguage + acceptEncoding).hashCode());
    }
}

