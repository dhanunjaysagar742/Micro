package com.dj.career.service;

import com.dj.career.dto.*;
import org.springframework.data.domain.Page;

import java.time.LocalDate;
import java.util.List;

public interface AttendanceService {
    
    // Check-in/Check-out operations
    AttendanceStatusResponse checkIn(Long userId, CheckInRequest request);
    AttendanceStatusResponse checkOut(Long userId, CheckOutRequest request);
    AttendanceStatusResponse getCurrentStatus(Long userId);
    
    // Attendance history and records
    Page<AttendanceStatusResponse> getAttendanceHistory(Long userId, int page, int size);
    List<AttendanceStatusResponse> getUserAttendance(Long userId, LocalDate startDate, LocalDate endDate);
    
    // Reports and summaries
    UserAttendanceSummary getMonthlySummary(Long userId, int month, int year);
    MonthlyAttendanceReportResponse generateMonthlyReport(MonthlyAttendanceReportRequest request);
    
    // Dashboard statistics
    AttendanceStatistics getDashboardStatistics();
    Object getUserDashboard(Long userId);
    
    // Regularization
    AttendanceStatusResponse regularizeAttendance(Long userId, RegularizeRequest request);
    List<RegularizeRequest> getPendingRegularizations(Long managerId);
    void approveRegularization(Long regularizationId, Long managerId);
    void rejectRegularization(Long regularizationId, Long managerId, String reason);
}
