package com.dj.career.service;


import com.dj.career.entity.Role;
import com.dj.career.entity.User;
import com.dj.career.repository.RoleRepository;
import com.dj.career.repository.UserRepository;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Set;

@Service
@RequiredArgsConstructor
@Slf4j
public class DataInitializationService {

    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;

    @PostConstruct
    @Transactional
    public void initializeDefaultData() {
        log.info("Initializing default data...");
        
        // Create default roles
        createRoleIfNotExists("ROLE_ADMIN", "Administrator role");
        createRoleIfNotExists("ROLE_USER", "Standard user role");
        createRoleIfNotExists("ROLE_MANAGER", "Manager role");
        
        // Create default admin user
        createAdminUserIfNotExists();
        
        log.info("Default data initialization completed");
    }

    private void createRoleIfNotExists(String roleName, String description) {
        if (!roleRepository.existsByName(roleName)) {
            Role role = new Role();
            role.setName(roleName);
            role.setDescription(description);
            roleRepository.save(role);
            log.info("Created role: {}", roleName);
        }
    }

    private void createAdminUserIfNotExists() {
        if (!userRepository.existsByUsername("admin")) {
            User admin = new User();
            admin.setUsername("admin");
            admin.setPasswordHash(passwordEncoder.encode("admin123"));
            admin.setFullName("System Administrator");
            admin.setEmail("admin@company.com");
            admin.setEnabled(true);
            
            Role adminRole = roleRepository.findByName("ROLE_ADMIN").orElseThrow();
            admin.setRoles(Set.of(adminRole));
            
            userRepository.save(admin);
            log.info("Created default admin user");
        }
    }
}

