package com.dj.career.service;

import com.dj.career.dto.NotificationResponse;
import com.dj.career.entity.Notification;
import com.dj.career.entity.NotificationType;
import org.springframework.data.domain.Page;

import java.util.List;

public interface NotificationService {
    
    // Create notifications
    Notification createNotification(Long userId, String title, String message, NotificationType type);
    Notification createNotification(Long userId, String title, String message, NotificationType type, String actionUrl);
    
    // Get notifications - ADD THIS METHOD
    Page<NotificationResponse> getUserNotifications(Long userId, int page, int size);
    List<NotificationResponse> getUnreadNotifications(Long userId);
    Long getUnreadCount(Long userId);
    
    // Mark notifications
    void markAsRead(Long notificationId, Long userId);
    void markAllAsRead(Long userId);
    
    // Delete notifications
    void deleteNotification(Long notificationId, Long userId);
    void cleanupOldNotifications();
    
    // Attendance-specific notifications
    void notifyAttendanceApproval(Long userId, String attendanceDate);
    void notifyAttendanceRejection(Long userId, String attendanceDate, String reason);
    void notifyLateArrival(Long userId, String date, String arrivalTime);
    void notifyMissedCheckout(Long userId, String date);
    void notifyMonthlyReport(Long userId, int month, int year);
}
