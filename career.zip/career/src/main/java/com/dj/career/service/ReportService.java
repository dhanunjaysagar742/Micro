package com.dj.career.service;

import com.dj.career.dto.*;
import java.time.LocalDate;
import java.util.List;

public interface ReportService {
    
    // Monthly reports
    MonthlyAttendanceReportResponse generateMonthlyReport(MonthlyAttendanceReportRequest request);
    AttendanceStatistics getDashboardStatistics();
    List<UserAttendanceSummary> getTopPerformers(int limit);
    
    // Export functionality
    byte[] exportToExcel(LocalDate startDate, LocalDate endDate, Long userId);
    byte[] exportToPdf(LocalDate startDate, LocalDate endDate, Long userId);
    
    // Department-wise reports
    List<DepartmentAttendanceSummary> getDepartmentWiseReport(int month, int year);
    
    // Trend analysis
    List<AttendanceTrendData> getAttendanceTrends(LocalDate startDate, LocalDate endDate);
}
