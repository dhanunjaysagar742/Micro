package com.dj.career.service;

import com.dj.career.dto.*;
import com.dj.career.entity.User;
import org.springframework.data.domain.Page;

public interface UserService {
    
    // Admin operations
    UserResponse createUser(CreateUserRequest request);
    Page<UserResponse> getAllUsers(int page, int size, String sortBy, String sortDir);
    Page<UserResponse> searchUsers(String search, int page, int size, String sortBy, String sortDir);
    void deleteUser(Long id);
    void enableUser(Long id);
    void disableUser(Long id);
    
    // User operations
    UserResponse getUserById(Long id);
    UserResponse updateUser(Long id, UpdateUserRequest request);
    Object getUserDashboard(Long userId);
    Object getUserNotifications(Long userId, boolean unreadOnly);
    void changePassword(Long userId, ChangePasswordRequest request);
    
    // Utility methods
    boolean existsByUsername(String username);
    boolean existsByEmail(String email);
    User findEntityById(Long id);
    User findEntityByUsername(String username);
	UserResponse getUserByUsername(String username);
	
	
}
