package com.dj.career.service.impl;

import com.dj.career.dto.*;
import com.dj.career.entity.AttendanceRecord;
import com.dj.career.entity.User;
import com.dj.career.entity.WorkMode;
import com.dj.career.exception.BusinessException;
import com.dj.career.exception.ResourceNotFoundException;
import com.dj.career.mapper.AttendanceMapper;
import com.dj.career.repository.AttendanceRepository;
import com.dj.career.service.AttendanceService;
import com.dj.career.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.YearMonth;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
@Slf4j
public class AttendanceServiceImpl implements AttendanceService {
    
    private final AttendanceRepository attendanceRepository;
    private final UserService userService;
    private final AttendanceMapper attendanceMapper;
    
    // Constants for business rules
    private static final int FULL_DAY_HOURS = 8;
    private static final int HALF_DAY_HOURS = 4;
    private static final LocalTime OFFICE_START_TIME = LocalTime.of(9, 0);
    private static final LocalTime LATE_THRESHOLD = LocalTime.of(9, 30);
    
    @Override
    public AttendanceStatusResponse checkIn(Long userId, CheckInRequest request) {
        log.info("Processing check-in for user ID: {}", userId);
        
        User user = userService.findEntityById(userId);
        
        // Validate check-in conditions
        validateCheckInConditions(user, request);
        
        // Create attendance record
        AttendanceRecord record = createAttendanceRecord(user, request);
        AttendanceRecord savedRecord = attendanceRepository.save(record);
        
        log.info("Check-in successful for user ID: {} at {}", userId, savedRecord.getCheckInTime());
        return attendanceMapper.toStatusResponse(savedRecord);
    }
    
    @Override
    public AttendanceStatusResponse checkOut(Long userId, CheckOutRequest request) {
        log.info("Processing check-out for user ID: {}", userId);
        
        User user = userService.findEntityById(userId);
        
        // Find active attendance record
        AttendanceRecord record = findActiveAttendanceRecord(user);
        
        // Validate and process check-out
        processCheckOut(record, request);
        
        AttendanceRecord updatedRecord = attendanceRepository.save(record);
        log.info("Check-out successful for user ID: {} at {} (Total: {} minutes)", 
                userId, updatedRecord.getCheckOutTime(), updatedRecord.getTotalWorkingMinutes());
        
        return attendanceMapper.toStatusResponse(updatedRecord);
    }
    
    @Override
    @Transactional(readOnly = true)
    public AttendanceStatusResponse getCurrentStatus(Long userId) {
        log.debug("Getting current status for user ID: {}", userId);
        
        User user = userService.findEntityById(userId);
        
        Optional<AttendanceRecord> activeRecord = 
            attendanceRepository.findByUserAndCheckOutTimeIsNull(user);
        
        if (activeRecord.isPresent()) {
            return attendanceMapper.toStatusResponse(activeRecord.get());
        }
        
        // Return default status if no active record
        return createDefaultStatus(user);
    }
    
    @Override
    @Transactional(readOnly = true)
    public Page<AttendanceStatusResponse> getAttendanceHistory(Long userId, int page, int size) {
        log.debug("Getting attendance history for user ID: {}", userId);
        
        User user = userService.findEntityById(userId);
        Sort sort = Sort.by(Sort.Direction.DESC, "checkInTime");
        Pageable pageable = PageRequest.of(page, size, sort);
        
        Page<AttendanceRecord> records = attendanceRepository.findByUserOrderByCheckInTimeDesc(user, pageable);
        return records.map(attendanceMapper::toStatusResponse);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<AttendanceStatusResponse> getUserAttendance(Long userId, LocalDate startDate, LocalDate endDate) {
        log.debug("Getting attendance for user ID: {} from {} to {}", userId, startDate, endDate);
        
        User user = userService.findEntityById(userId);
        
        LocalDateTime startDateTime = startDate.atStartOfDay();
        LocalDateTime endDateTime = endDate.atTime(23, 59, 59);
        
        List<AttendanceRecord> records = attendanceRepository.findByUserAndCheckInTimeBetween(
            user, startDateTime, endDateTime);
        
        return records.stream()
                .map(attendanceMapper::toStatusResponse)
                .collect(Collectors.toList());
    }
    
    @Override
    @Transactional(readOnly = true)
    public UserAttendanceSummary getMonthlySummary(Long userId, int month, int year) {
        log.debug("Generating monthly summary for user ID: {} for {}/{}", userId, month, year);
        
        User user = userService.findEntityById(userId);
        YearMonth yearMonth = YearMonth.of(year, month);
        
        LocalDateTime startDate = yearMonth.atDay(1).atStartOfDay();
        LocalDateTime endDate = yearMonth.atEndOfMonth().atTime(23, 59, 59);
        
        List<AttendanceRecord> records = attendanceRepository.findByUserAndCheckInTimeBetween(
            user, startDate, endDate);
        
        return calculateMonthlySummary(user, records, yearMonth);
    }
    
    @Override
    @Transactional(readOnly = true)
    public MonthlyAttendanceReportResponse generateMonthlyReport(MonthlyAttendanceReportRequest request) {
        log.info("Generating monthly report for {}/{}", request.getMonth(), request.getYear());
        
        YearMonth yearMonth = YearMonth.of(request.getYear(), request.getMonth());
        
        LocalDateTime startDate = yearMonth.atDay(1).atStartOfDay();
        LocalDateTime endDate = yearMonth.atEndOfMonth().atTime(23, 59, 59);
        
        List<AttendanceRecord> allRecords = attendanceRepository.findAttendanceInDateRange(startDate, endDate);
        
        return buildMonthlyReport(yearMonth, allRecords);
    }
    
    @Override
    @Transactional(readOnly = true)
    public AttendanceStatistics getDashboardStatistics() {
        log.debug("Generating dashboard statistics");
        
        Long todayPresent = attendanceRepository.countTodayTotalAttendance();
        Long todayCompleted = attendanceRepository.countTodayCompletedAttendance();
        
        AttendanceStatistics stats = new AttendanceStatistics();
        stats.setTotalPresentDays(todayPresent.intValue());
        
        if (todayPresent > 0) {
            double attendanceRate = (double) todayCompleted / todayPresent * 100;
            stats.setAverageAttendanceRate(attendanceRate);
        }
        
        // Add more statistics calculations as needed
        calculateAdditionalStats(stats);
        
        return stats;
    }
    
    @Override
    @Transactional(readOnly = true)
    public Object getUserDashboard(Long userId) {
        log.debug("Getting dashboard data for user ID: {}", userId);
        
        User user = userService.findEntityById(userId);
        
        // Get current month summary
        LocalDate today = LocalDate.now();
        UserAttendanceSummary monthlySummary = getMonthlySummary(userId, today.getMonthValue(), today.getYear());
        
        // Get current status
        AttendanceStatusResponse currentStatus = getCurrentStatus(userId);
        
        // Build dashboard response
        DashboardResponse dashboard = new DashboardResponse();
        dashboard.setCurrentUserStatus(currentStatus);
        dashboard.setMonthlySummary(monthlySummary);
        dashboard.setTodayDate(today);
        
        return dashboard;
    }
    
    @Override
    public AttendanceStatusResponse regularizeAttendance(Long userId, RegularizeRequest request) {
        log.info("Processing regularization request for user ID: {}", userId);
        
        User user = userService.findEntityById(userId);
        
        // Find attendance record for the specified date
        Optional<AttendanceRecord> existingRecord = 
            attendanceRepository.findByUserIdAndDate(userId, request.getDate());
        
        AttendanceRecord record;
        if (existingRecord.isPresent()) {
            record = existingRecord.get();
            updateExistingRecord(record, request);
        } else {
            record = createRegularizedRecord(user, request);
        }
        
        record.setRegularized(true);
        record.setRegularizationReason(request.getReason());
        record.setRegularizationStatus("PENDING");
        
        AttendanceRecord savedRecord = attendanceRepository.save(record);
        log.info("Regularization request submitted for user ID: {} for date: {}", userId, request.getDate());
        
        return attendanceMapper.toStatusResponse(savedRecord);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<RegularizeRequest> getPendingRegularizations(Long managerId) {
        // Implementation for getting pending regularization requests
        // This would depend on your specific business rules
        return List.of(); // Placeholder
    }
    
    @Override
    public void approveRegularization(Long regularizationId, Long managerId) {
        // Implementation for approving regularization
        log.info("Manager {} approving regularization {}", managerId, regularizationId);
    }
    
    @Override
    public void rejectRegularization(Long regularizationId, Long managerId, String reason) {
        // Implementation for rejecting regularization
        log.info("Manager {} rejecting regularization {} with reason: {}", managerId, regularizationId, reason);
    }
    
    // Private helper methods
    
    private void validateCheckInConditions(User user, CheckInRequest request) {
        // Check if user is already checked in
        Optional<AttendanceRecord> existingRecord = 
            attendanceRepository.findByUserAndCheckOutTimeIsNull(user);
        
        if (existingRecord.isPresent()) {
            throw new BusinessException("User is already checked in");
        }
        
        // Check if user already has attendance for today
        LocalDate today = LocalDate.now();
        Optional<AttendanceRecord> todayRecord = 
            attendanceRepository.findByUserIdAndDate(user.getId(), today);
        
        if (todayRecord.isPresent() && todayRecord.get().getCheckOutTime() != null) {
            throw new BusinessException("Attendance already completed for today");
        }
        
        // Additional business validations can be added here
    }
    
    private AttendanceRecord createAttendanceRecord(User user, CheckInRequest request) {
        AttendanceRecord record = new AttendanceRecord();
        record.setUser(user);
        record.setCheckInTime(request.getCheckInTime() != null ? 
                             request.getCheckInTime() : LocalDateTime.now());
        record.setCheckInLatitude(request.getLatitude());
        record.setCheckInLongitude(request.getLongitude());
        record.setCheckInLocation(request.getLocationName());
        record.setCheckInNotes(request.getNotes());
        record.setWorkMode(WorkMode.valueOf(request.getWorkMode()));
        
        // Check if late
        LocalTime checkInTime = record.getCheckInTime().toLocalTime();
        if (checkInTime.isAfter(LATE_THRESHOLD)) {
            record.setIsLate(true);
        }
        
        return record;
    }
    
    private AttendanceRecord findActiveAttendanceRecord(User user) {
        return attendanceRepository.findByUserAndCheckOutTimeIsNull(user)
                .orElseThrow(() -> new BusinessException("No active check-in found for user"));
    }
    
    private void processCheckOut(AttendanceRecord record, CheckOutRequest request) {
        LocalDateTime checkOutTime = request.getCheckOutTime() != null ? 
                                   request.getCheckOutTime() : LocalDateTime.now();
        
        if (checkOutTime.isBefore(record.getCheckInTime())) {
            throw new BusinessException("Check-out time cannot be before check-in time");
        }
        
        record.setCheckOutTime(checkOutTime);
        record.setCheckOutLatitude(request.getLatitude());
        record.setCheckOutLongitude(request.getLongitude());
        record.setCheckOutLocation(request.getLocationName());
        record.setCheckOutNotes(request.getNotes());
        record.setWorkSummary(request.getWorkSummary());
        
        // Calculate total working minutes and determine attendance status
        long workingMinutes = ChronoUnit.MINUTES.between(record.getCheckInTime(), checkOutTime);
        record.setTotalWorkingMinutes(workingMinutes);
        
        // Set attendance status based on working hours
        setAttendanceStatus(record, workingMinutes);
    }
    
    private void setAttendanceStatus(AttendanceRecord record, long workingMinutes) {
        double workingHours = workingMinutes / 60.0;
        
        if (workingHours >= FULL_DAY_HOURS) {
            record.setAttendanceStatus("PRESENT");
        } else if (workingHours >= HALF_DAY_HOURS) {
            record.setAttendanceStatus("HALF_DAY");
        } else {
            record.setAttendanceStatus("ABSENT");
        }
    }
    
    private AttendanceStatusResponse createDefaultStatus(User user) {
        AttendanceStatusResponse response = new AttendanceStatusResponse();
        response.setUserId(user.getId());
        response.setUsername(user.getUsername());
        response.setFullName(user.getFullName());
        response.setCheckedIn(false);
        response.setCurrentStatus("NOT_STARTED");
        
        return response;
    }
    
    private UserAttendanceSummary calculateMonthlySummary(User user, List<AttendanceRecord> records, YearMonth yearMonth) {
        UserAttendanceSummary summary = new UserAttendanceSummary();
        summary.setUserId(user.getId());
        summary.setUsername(user.getUsername());
        summary.setFullName(user.getFullName());
       // summary.setDepartment(user.getDepartment());
        //summary.setDesignation(user.getDesignation());
        
        // Calculate statistics
        int presentDays = 0;
        int halfDays = 0;
        int absentDays = 0;
        int lateDays = 0;
        long totalWorkingMinutes = 0;
        
        for (AttendanceRecord record : records) {
            if (record.getCheckOutTime() != null) {
                String status = record.getAttendanceStatus();
                switch (status) {
                    case "PRESENT":
                        presentDays++;
                        break;
                    case "HALF_DAY":
                        halfDays++;
                        break;
                    case "ABSENT":
                        absentDays++;
                        break;
                }
                
                if (record.isLate()) {
                    lateDays++;
                }
                
                totalWorkingMinutes += record.getTotalWorkingMinutes();
            }
        }
        
        int totalWorkingDays = yearMonth.lengthOfMonth() - getHolidaysCount(yearMonth);
        int totalAttendedDays = presentDays + halfDays;
        
        summary.setPresentDays(presentDays);
        summary.setAbsentDays(totalWorkingDays - totalAttendedDays);
        summary.setLateDays(lateDays);
        summary.setTotalWorkingHours(totalWorkingMinutes / 60);
        
        // Calculate attendance percentage
        if (totalWorkingDays > 0) {
            double attendancePercentage = ((double) totalAttendedDays / totalWorkingDays) * 100;
            summary.setAttendancePercentage(Math.round(attendancePercentage * 100.0) / 100.0);
        }
        
        // Calculate punctuality rate
        if (totalAttendedDays > 0) {
            double punctualityRate = ((double) (totalAttendedDays - lateDays) / totalAttendedDays) * 100;
            summary.setPunctualityRate(Math.round(punctualityRate * 100.0) / 100.0);
        }
        
        return summary;
    }
    
    private MonthlyAttendanceReportResponse buildMonthlyReport(YearMonth yearMonth, List<AttendanceRecord> allRecords) {
        MonthlyAttendanceReportResponse report = new MonthlyAttendanceReportResponse();
        report.setYear(yearMonth.getYear());
        report.setMonth(yearMonth.getMonthValue());
        report.setMonthName(yearMonth.getMonth().name());
        report.setTotalWorkingDays(yearMonth.lengthOfMonth() - getHolidaysCount(yearMonth));
        
        // Group records by user and calculate summaries
        // Implementation would depend on your specific requirements
        
        return report;
    }
    
    private void calculateAdditionalStats(AttendanceStatistics stats) {
        // Add more statistical calculations as needed
        stats.setTotalEmployees(50); // This should come from actual data
        stats.setPunctualityRate(85.5); // Calculate based on actual data
    }
    
    private int getHolidaysCount(YearMonth yearMonth) {
        // Return the number of holidays in the given month
        // This should be implemented based on your holiday management system
        return 4; // Placeholder
    }
    
    private void updateExistingRecord(AttendanceRecord record, RegularizeRequest request) {
        // Update existing record with regularization data
        record.setCheckInTime(request.getCheckInTime());
        record.setCheckOutTime(request.getCheckOutTime());
        record.setRegularizationReason(request.getReason());
    }
    
    private AttendanceRecord createRegularizedRecord(User user, RegularizeRequest request) {
        AttendanceRecord record = new AttendanceRecord();
        record.setUser(user);
        record.setCheckInTime(request.getCheckInTime());
        record.setCheckOutTime(request.getCheckOutTime());
        record.setWorkMode(WorkMode.valueOf(request.getWorkMode()));
        record.setRegularizationReason(request.getReason());
        
        // Calculate working minutes
        long workingMinutes = ChronoUnit.MINUTES.between(
            request.getCheckInTime(), request.getCheckOutTime());
        record.setTotalWorkingMinutes(workingMinutes);
        
        setAttendanceStatus(record, workingMinutes);
        
        return record;
    }
}
