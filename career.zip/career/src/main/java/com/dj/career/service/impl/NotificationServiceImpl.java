package com.dj.career.service.impl;

import com.dj.career.dto.NotificationResponse;
import com.dj.career.entity.Notification;
import com.dj.career.entity.NotificationType;
import com.dj.career.entity.User;
import com.dj.career.exception.BusinessException;
import com.dj.career.exception.ResourceNotFoundException;
import com.dj.career.mapper.NotificationMapper;
import com.dj.career.repository.NotificationRepository;
import com.dj.career.service.NotificationService;
import com.dj.career.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
@Slf4j
public class NotificationServiceImpl implements NotificationService {
    
    private final NotificationRepository notificationRepository;
    private final UserService userService;
    private final NotificationMapper notificationMapper;
    
    @Override
    public Notification createNotification(Long userId, String title, String message, NotificationType type) {
        log.debug("Creating notification for user ID: {}", userId);
        
        User user = userService.findEntityById(userId);
        Notification notification = new Notification(user, title, message, type);
        
        Notification savedNotification = notificationRepository.save(notification);
        log.info("Notification created with ID: {} for user: {}", savedNotification.getId(), userId);
        
        return savedNotification;
    }
    
    @Override
    public Notification createNotification(Long userId, String title, String message, 
                                         NotificationType type, String actionUrl) {
        log.debug("Creating notification with action URL for user ID: {}", userId);
        
        User user = userService.findEntityById(userId);
        Notification notification = new Notification(user, title, message, type, actionUrl);
        
        Notification savedNotification = notificationRepository.save(notification);
        log.info("Notification with action created with ID: {} for user: {}", 
                savedNotification.getId(), userId);
        
        return savedNotification;
    }
    
    @Override
    @Transactional(readOnly = true)
    public Page<NotificationResponse> getUserNotifications(Long userId, int page, int size) {
        log.debug("Getting notifications for user ID: {} (page: {}, size: {})", userId, page, size);
        
        User user = userService.findEntityById(userId);
        Sort sort = Sort.by(Sort.Direction.DESC, "createdAt");
        Pageable pageable = PageRequest.of(page, size, sort);
        
        Page<Notification> notifications = notificationRepository.findByUserOrderByCreatedAtDesc(user, pageable);
        return notifications.map(notificationMapper::toResponse);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<NotificationResponse> getUnreadNotifications(Long userId) {
        log.debug("Getting unread notifications for user ID: {}", userId);
        
        User user = userService.findEntityById(userId);
        List<Notification> notifications = notificationRepository.findByUserAndReadFalseOrderByCreatedAtDesc(user);
        
        return notifications.stream()
                .map(notificationMapper::toResponse)
                .collect(Collectors.toList());
    }
    
    @Override
    @Transactional(readOnly = true)
    public Long getUnreadCount(Long userId) {
        log.debug("Getting unread count for user ID: {}", userId);
        
        User user = userService.findEntityById(userId);
        return notificationRepository.countByUserAndReadFalse(user);
    }
    
    @Override
    public void markAsRead(Long notificationId, Long userId) {
        log.debug("Marking notification {} as read for user {}", notificationId, userId);
        
        Notification notification = notificationRepository.findById(notificationId)
                .orElseThrow(() -> new ResourceNotFoundException("Notification not found with id: " + notificationId));
        
        if (!notification.getUser().getId().equals(userId)) {
            throw new BusinessException("You can only mark your own notifications as read");
        }
        
        notification.setRead(true);
        notificationRepository.save(notification);
        
        log.info("Notification {} marked as read for user {}", notificationId, userId);
    }
    
    @Override
    public void markAllAsRead(Long userId) {
        log.debug("Marking all notifications as read for user ID: {}", userId);
        
        User user = userService.findEntityById(userId);
        notificationRepository.markAllAsReadByUser(user);
        
        log.info("All notifications marked as read for user {}", userId);
    }
    
    @Override
    public void deleteNotification(Long notificationId, Long userId) {
        log.debug("Deleting notification {} for user {}", notificationId, userId);
        
        Notification notification = notificationRepository.findById(notificationId)
                .orElseThrow(() -> new ResourceNotFoundException("Notification not found with id: " + notificationId));
        
        if (!notification.getUser().getId().equals(userId)) {
            throw new BusinessException("You can only delete your own notifications");
        }
        
        notificationRepository.delete(notification);
        log.info("Notification {} deleted for user {}", notificationId, userId);
    }
    
    @Override
    @Scheduled(cron = "0 0 2 * * ?") // Run daily at 2 AM
    public void cleanupOldNotifications() {
        log.info("Starting cleanup of old notifications");
        
        LocalDateTime cutoffDate = LocalDateTime.now().minusDays(30);
        notificationRepository.deleteOldReadNotifications(cutoffDate);
        
        log.info("Cleanup of old notifications completed");
    }
    
    // Attendance-specific notification methods
    
    @Override
    public void notifyAttendanceApproval(Long userId, String attendanceDate) {
        createNotification(userId, 
                          "Attendance Approved", 
                          "Your attendance for " + attendanceDate + " has been approved.", 
                          NotificationType.APPROVAL_GRANTED,
                          "/attendance/history");
    }
    
    @Override
    public void notifyAttendanceRejection(Long userId, String attendanceDate, String reason) {
        createNotification(userId, 
                          "Attendance Rejected", 
                          "Your attendance for " + attendanceDate + " has been rejected. Reason: " + reason, 
                          NotificationType.APPROVAL_DENIED,
                          "/attendance/regularize");
    }
    
    @Override
    public void notifyLateArrival(Long userId, String date, String arrivalTime) {
        createNotification(userId, 
                          "Late Arrival", 
                          "You arrived late on " + date + " at " + arrivalTime + ". Please ensure punctuality.", 
                          NotificationType.WARNING);
    }
    
    @Override
    public void notifyMissedCheckout(Long userId, String date) {
        createNotification(userId, 
                          "Missed Check-out", 
                          "You forgot to check out on " + date + ". Please regularize your attendance.", 
                          NotificationType.REMINDER,
                          "/attendance/regularize");
    }
    
    @Override
    public void notifyMonthlyReport(Long userId, int month, int year) {
        createNotification(userId, 
                          "Monthly Report Available", 
                          "Your attendance report for " + month + "/" + year + " is now available.", 
                          NotificationType.INFO,
                          "/reports/monthly");
    }
}
