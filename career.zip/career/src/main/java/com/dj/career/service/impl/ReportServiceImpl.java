package com.dj.career.service.impl;

import com.dj.career.dto.*;
import com.dj.career.entity.AttendanceRecord;
import com.dj.career.entity.User;
import com.dj.career.repository.AttendanceRepository;
import com.dj.career.repository.UserRepository;
import com.dj.career.service.ReportService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
@Slf4j
public class ReportServiceImpl implements ReportService {
    
    private final AttendanceRepository attendanceRepository;
    private final UserRepository userRepository;
    
    private static final int FULL_DAY_HOURS = 8;
    private static final int HALF_DAY_HOURS = 4;
    
    @Override
    public MonthlyAttendanceReportResponse generateMonthlyReport(MonthlyAttendanceReportRequest request) {
        log.info("Generating monthly report for {}/{}", request.getMonth(), request.getYear());
        
        YearMonth yearMonth = YearMonth.of(request.getYear(), request.getMonth());
        LocalDateTime startDate = yearMonth.atDay(1).atStartOfDay();
        LocalDateTime endDate = yearMonth.atEndOfMonth().atTime(23, 59, 59);
        
        // Get all attendance records for the month
        List<AttendanceRecord> allRecords = attendanceRepository.findAttendanceInDateRange(startDate, endDate);
        
        // Group by user
        Map<User, List<AttendanceRecord>> recordsByUser = allRecords.stream()
                .collect(Collectors.groupingBy(AttendanceRecord::getUser));
        
        // Generate user summaries
        List<UserAttendanceSummary> userSummaries = recordsByUser.entrySet().stream()
                .map(entry -> calculateUserSummary(entry.getKey(), entry.getValue(), yearMonth))
                .collect(Collectors.toList());
        
        // Calculate overall statistics
        AttendanceStatistics overallStats = calculateOverallStatistics(allRecords, yearMonth);
        
        MonthlyAttendanceReportResponse response = new MonthlyAttendanceReportResponse();
        response.setYear(request.getYear());
        response.setMonth(request.getMonth());
        response.setMonthName(yearMonth.getMonth().name());
        response.setTotalWorkingDays(getWorkingDaysInMonth(yearMonth));
        response.setTotalEmployees(userSummaries.size());
        response.setUserSummaries(userSummaries);
        response.setOverallStats(overallStats);
        
        return response;
    }
    
    @Override
    public AttendanceStatistics getDashboardStatistics() {
        log.debug("Generating dashboard statistics");
        
        LocalDate today = LocalDate.now();
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = today.atTime(23, 59, 59);
        
        List<AttendanceRecord> todayRecords = attendanceRepository.findAttendanceInDateRange(startOfDay, endOfDay);
        
        long totalUsers = userRepository.countEnabledUsers();
        long presentToday = todayRecords.stream()
                .filter(record -> "PRESENT".equals(record.getAttendanceStatus()))
                .count();
        long absentToday = totalUsers - presentToday;
        long lateToday = todayRecords.stream()
                .filter(AttendanceRecord::isLate)
                .count();
        
        AttendanceStatistics stats = new AttendanceStatistics();
        stats.setTotalEmployees(Math.toIntExact(totalUsers));
        stats.setTotalPresentDays(Math.toIntExact(presentToday));
        stats.setTotalAbsentDays(Math.toIntExact(absentToday));
        stats.setTotalLateDays(Math.toIntExact(lateToday));
        
        if (totalUsers > 0) {
            double attendanceRate = (double) presentToday / totalUsers * 100;
            stats.setAverageAttendanceRate(Math.round(attendanceRate * 100.0) / 100.0);
        }
        
        if (presentToday > 0) {
            double punctualityRate = (double) (presentToday - lateToday) / presentToday * 100;
            stats.setPunctualityRate(Math.round(punctualityRate * 100.0) / 100.0);
        }
        
        return stats;
    }
    
    @Override
    public List<UserAttendanceSummary> getTopPerformers(int limit) {
        log.debug("Getting top {} performers", limit);
        
        LocalDate now = LocalDate.now();
        YearMonth currentMonth = YearMonth.from(now);
        
        MonthlyAttendanceReportRequest request = new MonthlyAttendanceReportRequest();
        request.setYear(currentMonth.getYear());
        request.setMonth(currentMonth.getMonthValue());
        
        MonthlyAttendanceReportResponse report = generateMonthlyReport(request);
        
        return report.getUserSummaries().stream()
                .sorted((u1, u2) -> Double.compare(
                    u2.getAttendancePercentage() != null ? u2.getAttendancePercentage() : 0.0,
                    u1.getAttendancePercentage() != null ? u1.getAttendancePercentage() : 0.0))
                .limit(limit)
                .collect(Collectors.toList());
    }
    
    @Override
    public byte[] exportToExcel(LocalDate startDate, LocalDate endDate, Long userId) {
        log.info("Exporting attendance data to Excel from {} to {}", startDate, endDate);
        
        List<AttendanceRecord> records;
        if (userId != null) {
            User user = userRepository.findById(userId)
                    .orElseThrow(() -> new RuntimeException("User not found"));
            records = attendanceRepository.findByUserAndCheckInTimeBetween(
                user, startDate.atStartOfDay(), endDate.atTime(23, 59, 59));
        } else {
            records = attendanceRepository.findAttendanceInDateRange(
                startDate.atStartOfDay(), endDate.atTime(23, 59, 59));
        }
        
        return generateExcelReport(records, startDate, endDate);
    }
    
//    @Override
//    public byte[] exportToPdf(LocalDate startDate, LocalDate endDate, Long userId) {
//        // PDF generation implementation would go here
//        // For now, returning empty byte array as placeholder
//        log.info("PDF export requested from {} to {}", startDate, endDate);
//        return new byte;
//    }
    
    @Override
    public List<DepartmentAttendanceSummary> getDepartmentWiseReport(int month, int year) {
        log.debug("Generating department-wise report for {}/{}", month, year);
        
        YearMonth yearMonth = YearMonth.of(year, month);
        LocalDateTime startDate = yearMonth.atDay(1).atStartOfDay();
        LocalDateTime endDate = yearMonth.atEndOfMonth().atTime(23, 59, 59);
        
        List<AttendanceRecord> records = attendanceRepository.findAttendanceInDateRange(startDate, endDate);
        
//        Map<String, List<AttendanceRecord>> recordsByDepartment = records.stream()
//                .filter(record -> record.getUser().getDepartment() != null)
//                .collect(Collectors.groupingBy(record -> record.getUser().getDepartment()));

        Map<String, List<AttendanceRecord>> recordsByDepartment = records.stream()
                .filter(record -> record.getUser().getFullName()!=null)
                .collect(Collectors.groupingBy(record -> record.getUser().getFullName()));
        
        return recordsByDepartment.entrySet().stream()
                .map(entry -> {
                    String department = entry.getKey();
                    List<AttendanceRecord> deptRecords = entry.getValue();
                    
                    DepartmentAttendanceSummary summary = new DepartmentAttendanceSummary();
                    summary.setDepartmentName(department);
                    summary.setTotalEmployees(Math.toIntExact(deptRecords.stream()
                        .map(AttendanceRecord::getUser)
                        .distinct()
                        .count()));
                    
                    long presentCount = deptRecords.stream()
                        .filter(record -> "PRESENT".equals(record.getAttendanceStatus()))
                        .count();
                    
                    summary.setTotalPresentDays(Math.toIntExact(presentCount));
                    
                    if (!deptRecords.isEmpty()) {
                        double avgAttendance = (double) presentCount / deptRecords.size() * 100;
                        summary.setAverageAttendanceRate(Math.round(avgAttendance * 100.0) / 100.0);
                    }
                    
                    return summary;
                })
                .sorted(Comparator.comparing(DepartmentAttendanceSummary::getDepartmentName))
                .collect(Collectors.toList());
    }
    
    @Override
    public List<AttendanceTrendData> getAttendanceTrends(LocalDate startDate, LocalDate endDate) {
        log.debug("Generating attendance trends from {} to {}", startDate, endDate);
        
        List<AttendanceRecord> records = attendanceRepository.findAttendanceInDateRange(
            startDate.atStartOfDay(), endDate.atTime(23, 59, 59));
        
        Map<LocalDate, List<AttendanceRecord>> recordsByDate = records.stream()
                .collect(Collectors.groupingBy(record -> record.getCheckInTime().toLocalDate()));
        
        return recordsByDate.entrySet().stream()
                .map(entry -> {
                    LocalDate date = entry.getKey();
                    List<AttendanceRecord> dayRecords = entry.getValue();
                    
                    AttendanceTrendData trendData = new AttendanceTrendData();
                    trendData.setDate(date);
                    trendData.setTotalAttendance(dayRecords.size());
                    trendData.setPresentCount((int) dayRecords.stream()
                        .filter(record -> "PRESENT".equals(record.getAttendanceStatus()))
                        .count());
                    trendData.setAbsentCount(dayRecords.size() - trendData.getPresentCount());
                    
                    if (dayRecords.size() > 0) {
                        double rate = (double) trendData.getPresentCount() / dayRecords.size() * 100;
                        trendData.setAttendanceRate(Math.round(rate * 100.0) / 100.0);
                    }
                    
                    return trendData;
                })
                .sorted(Comparator.comparing(AttendanceTrendData::getDate))
                .collect(Collectors.toList());
    }
    
    // Private helper methods
    
    private UserAttendanceSummary calculateUserSummary(User user, List<AttendanceRecord> records, YearMonth yearMonth) {
        UserAttendanceSummary summary = new UserAttendanceSummary();
        summary.setUserId(user.getId());
        summary.setUsername(user.getUsername());
        summary.setFullName(user.getFullName());
       // summary.setDepartment(user.getDepartment());
        //summary.setDesignation(user.getDesignation());
        
        int presentDays = 0;
        int halfDays = 0;
        int lateDays = 0;
        long totalWorkingMinutes = 0;
        
        for (AttendanceRecord record : records) {
            if (record.getCheckOutTime() != null) {
                String status = record.getAttendanceStatus();
                if ("PRESENT".equals(status)) {
                    presentDays++;
                } else if ("HALF_DAY".equals(status)) {
                    halfDays++;
                }
                
                if (record.isLate()) {
                    lateDays++;
                }
                
                if (record.getTotalWorkingMinutes() != null) {
                    totalWorkingMinutes += record.getTotalWorkingMinutes();
                }
            }
        }
        
        int totalWorkingDays = getWorkingDaysInMonth(yearMonth);
        int totalAttendedDays = presentDays + halfDays;
        
        summary.setPresentDays(presentDays);
        summary.setAbsentDays(totalWorkingDays - totalAttendedDays);
        summary.setLateDays(lateDays);
        summary.setTotalWorkingHours(totalWorkingMinutes / 60);
        
        if (totalWorkingDays > 0) {
            double attendancePercentage = (double) totalAttendedDays / totalWorkingDays * 100;
            summary.setAttendancePercentage(Math.round(attendancePercentage * 100.0) / 100.0);
        }
        
        if (totalAttendedDays > 0) {
            double punctualityRate = (double) (totalAttendedDays - lateDays) / totalAttendedDays * 100;
            summary.setPunctualityRate(Math.round(punctualityRate * 100.0) / 100.0);
        }
        
        return summary;
    }
    
    private AttendanceStatistics calculateOverallStatistics(List<AttendanceRecord> records, YearMonth yearMonth) {
        AttendanceStatistics stats = new AttendanceStatistics();
        
        long totalRecords = records.size();
        long presentRecords = records.stream()
                .filter(record -> "PRESENT".equals(record.getAttendanceStatus()))
                .count();
        long lateRecords = records.stream()
                .filter(AttendanceRecord::isLate)
                .count();
        
        stats.setTotalPresentDays(Math.toIntExact(presentRecords));
        stats.setTotalAbsentDays(Math.toIntExact(totalRecords - presentRecords));
        stats.setTotalLateDays(Math.toIntExact(lateRecords));
        
        if (totalRecords > 0) {
            double attendanceRate = (double) presentRecords / totalRecords * 100;
            stats.setAverageAttendanceRate(Math.round(attendanceRate * 100.0) / 100.0);
        }
        
        if (presentRecords > 0) {
            double punctualityRate = (double) (presentRecords - lateRecords) / presentRecords * 100;
            stats.setPunctualityRate(Math.round(punctualityRate * 100.0) / 100.0);
        }
        
        long totalWorkingMinutes = records.stream()
                .filter(record -> record.getTotalWorkingMinutes() != null)
                .mapToLong(AttendanceRecord::getTotalWorkingMinutes)
                .sum();
        
        stats.setTotalWorkingHours(totalWorkingMinutes / 60);
        
        return stats;
    }
    
    private byte[] generateExcelReport(List<AttendanceRecord> records, LocalDate startDate, LocalDate endDate) {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Attendance Report");
            
            // Create header row
            Row headerRow = sheet.createRow(0);
            String[] headers = {"Date", "Employee Name", "Department", "Check In", "Check Out", 
                              "Working Hours", "Status", "Work Mode"};
            
            for (int i = 0; i < headers.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers[i]);
                
                // Style header
                CellStyle headerStyle = workbook.createCellStyle();
                Font headerFont = workbook.createFont();
                headerFont.setBold(true);
                headerStyle.setFont(headerFont);
                cell.setCellStyle(headerStyle);
            }
            
            // Fill data rows
            int rowIndex = 1;
            DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
            
            for (AttendanceRecord record : records) {
                Row row = sheet.createRow(rowIndex++);
                
                row.createCell(0).setCellValue(record.getCheckInTime().toLocalDate().format(dateFormatter));
                row.createCell(1).setCellValue(record.getUser().getFullName());
               // row.createCell(2).setCellValue(record.getUser().getDepartment() != null ? 
                 //                             record.getUser().getDepartment() : "N/A");
                row.createCell(3).setCellValue(record.getCheckInTime().format(timeFormatter));
                row.createCell(4).setCellValue(record.getCheckOutTime() != null ? 
                                              record.getCheckOutTime().format(timeFormatter) : "Not Checked Out");
                
                if (record.getTotalWorkingMinutes() != null) {
                    double hours = record.getTotalWorkingMinutes() / 60.0;
                    row.createCell(5).setCellValue(String.format("%.2f", hours));
                } else {
                    row.createCell(5).setCellValue("N/A");
                }
                
                row.createCell(6).setCellValue(record.getAttendanceStatus() != null ? 
                                              record.getAttendanceStatus() : "Unknown");
                row.createCell(7).setCellValue(record.getWorkMode().name());
            }
            
            // Auto-size columns
            for (int i = 0; i < headers.length; i++) {
                sheet.autoSizeColumn(i);
            }
            
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            workbook.write(outputStream);
            return outputStream.toByteArray();
            
        } catch (IOException e) {
            log.error("Error generating Excel report", e);
            throw new RuntimeException("Failed to generate Excel report", e);
        }
    }
    
    private int getWorkingDaysInMonth(YearMonth yearMonth) {
        // Simple implementation - excludes weekends
        // You can enhance this to include company holidays
        int workingDays = 0;
        LocalDate date = yearMonth.atDay(1);
        
        while (date.getMonthValue() == yearMonth.getMonthValue()) {
            if (date.getDayOfWeek().getValue() <= 5) { // Monday to Friday
                workingDays++;
            }
            date = date.plusDays(1);
        }
        
        return workingDays;
    }

	@Override
	public byte[] exportToPdf(LocalDate startDate, LocalDate endDate, Long userId) {
		// TODO Auto-generated method stub
		return null;
	}
}
