package com.dj.career.service.impl;

import com.dj.career.dto.*;
import com.dj.career.entity.Role;
import com.dj.career.entity.User;
import com.dj.career.exception.BusinessException;
import com.dj.career.exception.ResourceNotFoundException;
import com.dj.career.exception.DuplicateResourceException;
import com.dj.career.mapper.UserMapper;
import com.dj.career.repository.UserRepository;
import com.dj.career.repository.RoleRepository;
import com.dj.career.service.UserService;
import com.dj.career.service.NotificationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.hibernate.validator.internal.util.stereotypes.Lazy;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
@Transactional
@Slf4j
public class UserServiceImpl implements UserService {
    
    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final UserMapper userMapper;
    private final PasswordEncoder passwordEncoder;
    @Lazy  // Add @Lazy to break the circular dependency
    private final NotificationService notificationService;
    
    public UserServiceImpl(UserRepository userRepository,
            RoleRepository roleRepository,
            UserMapper userMapper,
            PasswordEncoder passwordEncoder,
            @org.springframework.context.annotation.Lazy NotificationService notificationService) {
this.userRepository = userRepository;
this.roleRepository = roleRepository;
this.userMapper = userMapper;
this.passwordEncoder = passwordEncoder;
this.notificationService = notificationService;
}
    
    @Override
    public UserResponse createUser(CreateUserRequest request) {
        log.info("Creating user with username: {}", request.getUsername());
        
        if (userRepository.existsByUsername(request.getUsername())) {
            throw new DuplicateResourceException("Username already exists: " + request.getUsername());
        }
        
        if (request.getEmail() != null && userRepository.existsByEmail(request.getEmail())) {
            throw new DuplicateResourceException("Email already exists: " + request.getEmail());
        }
        
        User user = new User();
        user.setUsername(request.getUsername());
        user.setPasswordHash(passwordEncoder.encode(request.getPassword()));
        user.setFullName(request.getFullName());
        user.setEmail(request.getEmail());
        user.setEnabled(true);
        
        // Handle roles
        Set<Role> userRoles = new HashSet<>();
        if (request.getRoles() != null && !request.getRoles().isEmpty()) {
            for (String roleName : request.getRoles()) {
                Role role = roleRepository.findByName(roleName)
                    .orElseThrow(() -> new ResourceNotFoundException("Role not found: " + roleName));
                userRoles.add(role);
            }
        } else {
            // Default role
            Role defaultRole = roleRepository.findByName("USER")
                .orElseThrow(() -> new ResourceNotFoundException("Default USER role not found"));
            userRoles.add(defaultRole);
        }
        user.setRoles(userRoles);
        
        User savedUser = userRepository.save(user);
        log.info("User created successfully with ID: {}", savedUser.getId());
        
        return userMapper.toResponse(savedUser);
    }
    
    @Override
    public UserResponse updateUser(Long id, UpdateUserRequest request) {
        log.info("Updating user with ID: {}", id);
        
        User user = findEntityById(id);
        
        if (request.getEmail() != null && !request.getEmail().equals(user.getEmail()) 
            && userRepository.existsByEmail(request.getEmail())) {
            throw new DuplicateResourceException("Email already exists: " + request.getEmail());
        }
        
        // Update fields
        if (request.getFullName() != null) {
            user.setFullName(request.getFullName());
        }
        if (request.getEmail() != null) {
            user.setEmail(request.getEmail());
        }
        // Add other field updates as needed
        
        User updatedUser = userRepository.save(user);
        log.info("User updated successfully with ID: {}", updatedUser.getId());
        
        return userMapper.toResponse(updatedUser);
    }
    
    @Override
    @Transactional(readOnly = true)
    public UserResponse getUserById(Long id) {
        User user = findEntityById(id);
        return userMapper.toResponse(user);
    }
    
    @Override
    @Transactional(readOnly = true)
    public UserResponse getUserByUsername(String username) {
        User user = findEntityByUsername(username);
        return userMapper.toResponse(user);
    }
    
    @Override
    @Transactional(readOnly = true)
    public Page<UserResponse> getAllUsers(int page, int size, String sortBy, String sortDir) {
        Sort sort = sortDir.equalsIgnoreCase("desc") ? 
                   Sort.by(sortBy).descending() : Sort.by(sortBy).ascending();
        
        Pageable pageable = PageRequest.of(page, size, sort);
        Page<User> users = userRepository.findByEnabledTrue(pageable);
        
        return users.map(userMapper::toResponse);
    }
    
    @Override
    @Transactional(readOnly = true)
    public Page<UserResponse> searchUsers(String search, int page, int size, String sortBy, String sortDir) {
        Sort sort = sortDir.equalsIgnoreCase("desc") ? 
                   Sort.by(sortBy).descending() : Sort.by(sortBy).ascending();
        
        Pageable pageable = PageRequest.of(page, size, sort);
        Page<User> users = userRepository.findEnabledUsersWithSearch(search, pageable);
        
        return users.map(userMapper::toResponse);
    }
    
    @Override
    public void deleteUser(Long id) {
        log.info("Deleting user with ID: {}", id);
        User user = findEntityById(id);
        userRepository.delete(user);
        log.info("User deleted successfully with ID: {}", id);
    }
    
    @Override
    public void enableUser(Long id) {
        log.info("Enabling user with ID: {}", id);
        User user = findEntityById(id);
        user.setEnabled(true);
        userRepository.save(user);
        log.info("User enabled successfully with ID: {}", id);
    }
    
    @Override
    public void disableUser(Long id) {
        log.info("Disabling user with ID: {}", id);
        User user = findEntityById(id);
        user.setEnabled(false);
        userRepository.save(user);
        log.info("User disabled successfully with ID: {}", id);
    }
    
    // MISSING METHOD 1: changePassword
    @Override
    public void changePassword(Long userId, ChangePasswordRequest request) {
        log.info("Changing password for user ID: {}", userId);
        
        // Validate that new password and confirm password match
        if (!request.getNewPassword().equals(request.getConfirmPassword())) {
            throw new BusinessException("New password and confirm password do not match");
        }
        
        User user = findEntityById(userId);
        
        // Verify current password
        if (!passwordEncoder.matches(request.getCurrentPassword(), user.getPasswordHash())) {
            throw new BusinessException("Current password is incorrect");
        }
        
        // Update password
        user.setPasswordHash(passwordEncoder.encode(request.getNewPassword()));
        userRepository.save(user);
        
        log.info("Password changed successfully for user ID: {}", userId);
        
        // Send notification
        notificationService.createNotification(userId, 
            "Password Changed", 
            "Your password has been successfully changed.", 
            com.dj.career.entity.NotificationType.SUCCESS);
    }
    
    // MISSING METHOD 2: getUserNotifications
    @Override
    @Transactional(readOnly = true)
    public List<NotificationResponse> getUserNotifications(Long userId, boolean unreadOnly) {
        log.debug("Getting notifications for user ID: {} (unreadOnly: {})", userId, unreadOnly);
        
        if (unreadOnly) {
            return notificationService.getUnreadNotifications(userId);
        } else {
            // Get first page of notifications (last 20)
            Page<NotificationResponse> notifications = notificationService.getUserNotifications(userId, 0, 20);
            return notifications.getContent();
        }
    }
    
    // MISSING METHOD 3: getUserDashboard
    @Override
    @Transactional(readOnly = true)
    public Object getUserDashboard(Long userId) {
        log.debug("Getting dashboard data for user ID: {}", userId);
        
        User user = findEntityById(userId);
        
        // Build dashboard response
        UserDashboardResponse dashboard = new UserDashboardResponse();
        dashboard.setUserId(userId);
        dashboard.setFullName(user.getFullName());
        dashboard.setEmail(user.getEmail());
       // dashboard.setDepartment(user.getDepartment());
        //dashboard.setDesignation(user.getDesignation());
        dashboard.setTodayDate(LocalDate.now());
        
        // Get unread notification count
        Long unreadCount = notificationService.getUnreadCount(userId);
        dashboard.setUnreadNotificationCount(unreadCount);
        
        // Get recent notifications (last 5)
        List<NotificationResponse> recentNotifications = notificationService.getUnreadNotifications(userId)
                .stream()
                .limit(5)
                .toList();
        dashboard.setRecentNotifications(recentNotifications);
        
        return dashboard;
    }
    
    @Override
    @Transactional(readOnly = true)
    public boolean existsByUsername(String username) {
        return userRepository.existsByUsername(username);
    }
    
    @Override
    @Transactional(readOnly = true)
    public boolean existsByEmail(String email) {
        return userRepository.existsByEmail(email);
    }
    
    @Override
    @Transactional(readOnly = true)
    public User findEntityById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
    }
    
    @Override
    @Transactional(readOnly = true)
    public User findEntityByUsername(String username) {
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with username: " + username));
    }
}
