package com.dj.career;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest(classes = CareerApplication.class)
@ActiveProfiles("test")
class CareerApplicationTests {

    @Test
    void contextLoads() {
        // Context loading test
    }

}
